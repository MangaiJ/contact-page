$(document).ready(function() {

    var contact_container = $(".o-contact-form-container");
    var contact_open_btn = $(".o-contact__action-open");
    var contact_close_btn = $(".o-contact__action-close");

    $(contact_open_btn).click(function() {
        if(contact_container.length) {
            $(this).toggle();
            $(contact_container).slideToggle();
            $(contact_close_btn).toggle();
        }
    });

    $(contact_close_btn).click(function() {
        if(contact_container.length) {
            $(this).toggle();
            $(contact_container).slideToggle();
            $(contact_open_btn).toggle();
        }
    });

});
$(function() {    
$.validator.addMethod("regex", function(value, element, regexpr) {          
     return regexpr.test(value);
   });
    $("form[name='contact']").validate({      
      rules: {        
        firstname: {
        required: true,
        regex: /^[a-zA-Z]+$/			
        },
        lastname: {
          required: true,
          regex: /^[a-zA-Z]+$/			
        },        
        email: {
          required: true,
          email: true
        },
        enquiry: "required",
        message: "required"
      },
      messages: {
        firstname: { 
          required:"Please enter your firstname",
          regex: "please enter alpha char only"
        },
        lastname: { 
          required:"Please enter your lastname",
          regex: "please enter alpha char only"
        },        
        email: {
          required: "Please enter email",
          email: "Please enter a valid email address"
        },
	    	enquiry: "Please select enquiry type",
        message: "Please enter a message"
      },
      submitHandler: function(form) {
        form.submit();
      }
    });
  });