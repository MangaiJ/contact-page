﻿/* gulpfile.js */
var conf = require('./config.json'),
gulp = require('gulp'),
sass = require('gulp-sass');
concat = require('gulp-concat');
rename = require('gulp-rename');
LiveServer = require('gulp-live-server');
browserSync = require('browser-sync').create();
uglify = require('gulp-uglify');
plumber = require('gulp-plumber');

var scss = {
watch: conf.src.sass + '**/*',
sassOpts: {
    outputStyle: 'nested',
    precison: 3,
    errLogToConsole: true,
    includePaths: ['src/**/*']
}
};

gulp.task('vendor', function() {
    return gulp.src(conf.vendor.src)
        .pipe(concat('vendor.js'))
        .pipe(gulp.dest(conf.dest.js))
        .pipe(uglify())
        .pipe(rename({
            suffix: '.min'
        }))
        .pipe(gulp.dest(conf.dest.js));
});
gulp.task('customscript', function() {   
    return gulp.src(conf.custom.src)
        .pipe(plumber())
        .pipe(concat('app.js'))
        .pipe(gulp.dest(conf.dest.js))
        .pipe(uglify())
        .pipe(rename({
            suffix: '.min'
        }))
        .pipe(gulp.dest(conf.dest.js))
        .pipe(browserSync.stream());
});
gulp.task('sass', function () {
return gulp.src(conf.src.sass + '/**/*.scss')
    .pipe(sass(scss.sassOpts))
    .pipe(gulp.dest(conf.dest.css));    
});
gulp.task('serve', ['sass'], function() {    
    browserSync.init(null,{
        server: {
            baseDir: "./",
            proxy: "localhost",            
            index: "index.html"
        }
    });       
});


gulp.task('default', ['serve','vendor', 'customscript']);




