$(document).ready(function() {

    var contact_container = $(".o-contact-form-container");
    var contact_open_btn = $(".o-contact__action-open");
    var contact_close_btn = $(".o-contact__action-close");

    $(contact_open_btn).click(function() {
        if(contact_container.length) {
            $(this).toggle();
            $(contact_container).slideToggle();
            $(contact_close_btn).toggle();
        }
    });

    $(contact_close_btn).click(function() {
        if(contact_container.length) {
            $(this).toggle();
            $(contact_container).slideToggle();
            $(contact_open_btn).toggle();
        }
    });

});