$(function() {    
$.validator.addMethod("regex", function(value, element, regexpr) {          
     return regexpr.test(value);
   });
    $("form[name='contact']").validate({      
      rules: {        
        firstname: {
        required: true,
        regex: /^[a-zA-Z]+$/			
        },
        lastname: {
          required: true,
          regex: /^[a-zA-Z]+$/			
        },        
        email: {
          required: true,
          email: true
        },
        enquiry: "required",
        message: "required"
      },
      messages: {
        firstname: { 
          required:"Please enter your firstname",
          regex: "please enter alpha char only"
        },
        lastname: { 
          required:"Please enter your lastname",
          regex: "please enter alpha char only"
        },        
        email: {
          required: "Please enter email",
          email: "Please enter a valid email address"
        },
	    	enquiry: "Please select enquiry type",
        message: "Please enter a message"
      },
      submitHandler: function(form) {
        form.submit();
      }
    });
  });